package com.example.budget;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BudgetApplicationTests {

    @Test
    void contextLoads() {
    }

}
